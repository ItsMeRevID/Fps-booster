package com.mythicfps;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;

import com.mythicfps.event.ClientOptimizationEvents;
import com.mythicfps.event.EntityOptimizationEvents;
import com.mythicfps.event.ParticleOptimizationEvents;

@Mod(MythicFPS.MOD_ID)
public class MythicFPS {

    public static final String MOD_ID = "mythicfps";

    public MythicFPS() {
        MinecraftForge.EVENT_BUS.register(new ClientOptimizationEvents());
        MinecraftForge.EVENT_BUS.register(new EntityOptimizationEvents());
        MinecraftForge.EVENT_BUS.register(new ParticleOptimizationEvents());
    }
}
