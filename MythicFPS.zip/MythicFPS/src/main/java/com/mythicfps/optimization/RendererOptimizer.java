package com.mythicfps.optimization;

public class RendererOptimizer {

    public static void optimize() {

        System.setProperty("forge.forceNoStencil", "true");

        System.setProperty("sun.java2d.opengl", "true");
    }
}
