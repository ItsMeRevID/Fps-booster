package com.mythicfps.optimization;

public class TickOptimizer {

    public static boolean shouldSkipTick(int ticks) {

        return ticks % 2 == 0;
    }
}
