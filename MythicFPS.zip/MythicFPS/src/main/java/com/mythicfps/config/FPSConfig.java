package com.mythicfps.config;

public class FPSConfig {

    public static boolean DISABLE_EXCESS_PARTICLES = true;

    public static boolean LIMIT_ENTITY_RENDER = true;

    public static boolean OPTIMIZE_TICKS = true;

    public static int ENTITY_RENDER_DISTANCE = 48;
}
