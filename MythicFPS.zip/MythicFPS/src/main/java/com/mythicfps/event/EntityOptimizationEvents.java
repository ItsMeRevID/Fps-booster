package com.mythicfps.event;

import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;

public class EntityOptimizationEvents {

    @SubscribeEvent
    public void onEntitySpawn(EntityJoinWorldEvent event) {

        Entity entity = event.getEntity();

        if (entity instanceof ItemEntity) {
            entity.setNoGravity(true);
        }
    }
}
