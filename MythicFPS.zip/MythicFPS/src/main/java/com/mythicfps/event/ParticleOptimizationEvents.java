package com.mythicfps.event;

import net.minecraftforge.client.event.ParticleFactoryRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ParticleOptimizationEvents {

    @SubscribeEvent
    public void optimizeParticles(ParticleFactoryRegisterEvent event) {

        // Particle optimization placeholder
    }
}
