package com.mythicfps.event;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ClientOptimizationEvents {

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        if (Runtime.getRuntime().freeMemory() < 200000000L) {
            System.gc();
        }
    }
}
